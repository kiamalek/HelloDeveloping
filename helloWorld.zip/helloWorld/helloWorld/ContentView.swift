 import SwiftUI
import SDWebImageSwiftUI

struct CenteredImage: View {
    @State private var isTableViewLoaded = false

    var body: some View {
        ZStack {
            GeometryReader { geometry in
                WebImage(url: URL(string: "https://www.freepik.com/free-vector/vector-banner-software-development_9750031.htm#query=app%20developing&position=5&from_view=search&track=ais")) // Replace "https://kiaapp.xyz/wp-content/uploads/2023/05/Kia1-225x300.jpeg" with the URL of the developing photo from the internet
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: geometry.size.width * 0.6, height: geometry.size.width * 0.6)
                    .clipped()
                    .opacity(0.8)
                    .overlay(
                        VStack {
                            Spacer()
                            Button(action: {
                                isTableViewLoaded = true
                            }) {
                                Text("Load Table View")
                                    .font(.headline)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                    )
            }
        }
        .sheet(isPresented: $isTableViewLoaded) {
            TableView()
        }
    }
}

struct TableView: View {
    var body: some View {
        List {
            TableRow(title: "Flutter", description: "Flutter is a UI toolkit for building natively compiled applications for mobile, web, and desktop from a single codebase.")
            TableRow(title: "Xcode", description: "Xcode is an integrated development environment (IDE) for macOS containing a suite of software development tools.")
            TableRow(title: "GitHub", description: "GitHub is a web-based hosting service for version control using Git. It provides a platform for collaboration and code sharing.")
            TableRow(title: "WordPress", description: "WordPress is a free and open-source content management system (CMS) used for creating websites and blogs.")
            TableRow(title: "Photoshop", description: "Photoshop is a raster graphics editor developed and published by Adobe Inc. It is widely used for image editing and graphic design.")
        }
        .navigationTitle("Table View")
    }
}

struct TableRow: View {
    var title: String
    var description: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
            Text(description)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding()
    }
}

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("I'm an iOS developer")
                .font(.title)
                .padding(.all)
            VStack {
                Text("I'd like to ease my life by app developing")
                    .font(.subheadline)
                    .imageScale(.large)
                    .foregroundColor(.brown)
                Spacer()
                Text("Always try to be creative")
                    .font(.title3)
            }
            .padding(.bottom, 100) // Added padding to make space for the image
        }
        CenteredImage() // Centered image added here
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
