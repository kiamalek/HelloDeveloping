//
//  helloWorldApp.swift
//  helloWorld
//
//  Created by Kia Malek on 19.07.23.
//

import SwiftUI

@main
struct helloWorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
